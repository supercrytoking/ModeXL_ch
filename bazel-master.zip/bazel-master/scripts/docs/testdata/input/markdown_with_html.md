Project: /_project.yaml
Book: /_book.yaml

Lorem ipsum [short link](/foo/bar). Or rather a [long link](https://bazel.build/foo/bar)?

![Scalability graph](/rules/scalability-graph.png "Scalability graph")

**Figure 1.** Scalability graph.

Please ignore this [relative link](relative/link).

This might be a <a href="/foo/bar">test</a>,

<img src="https://bazel.build/images/test.jpg">
