package bazel;

/**
 * A tiny library for the Bazel Android "Hello, World" app.
 */
public class Lib {
  public static String message() {
    return "Hello Lib";
  }
}
