# Starlark interface framework

The classes in this package define annotations and interfaces used to enable
Starlark access to data types and methods implemented in Java.
